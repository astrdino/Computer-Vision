#!/usr/bin/env bash

python util/mesh_viewer.py \
--files \
checkpoints/coseg_aliens/meshes/142_0.obj \
checkpoints/coseg_aliens/meshes/142_2.obj \
checkpoints/coseg_aliens/meshes/142_3.obj \