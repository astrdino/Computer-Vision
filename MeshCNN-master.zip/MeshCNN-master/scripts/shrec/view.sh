#!/usr/bin/env bash

python util/mesh_viewer.py \
--files \
checkpoints/shrec16/meshes/T74_0.obj \
checkpoints/shrec16/meshes/T74_3.obj \
checkpoints/shrec16/meshes/T74_4.obj