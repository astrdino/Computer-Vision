#!/usr/bin/env bash

python util/mesh_viewer.py \
--files \
checkpoints/human_seg/meshes/shrec__14_0.obj